$(document).ready(function(){ 
  var i = 0;
  $('#man').attr('src', 'img/mario.gif');
  $('#img-span').animate({left: '20%'}, 1000);
  var en = 0;;
  console.log(en?"yes":"no")
  $(this).keydown(function(e){
    
    var k = e.which;
    var leftVal = $('#road').css('background-position-x');
    var getValofLeft = leftVal.slice(0, leftVal.indexOf('%'));
    var makeNum = parseInt(getValofLeft,10);

    // Enemy var 
    var enLeftVal = $('#en').css('right');
    var getValOfEn = enLeftVal.slice(0, enLeftVal.indexOf('%'));
    var makeEnNum = parseInt(getValOfEn,10);
    console.log("left",enLeftVal, "getEnVal", getValOfEn, "num",makeEnNum)
    if(k === 39){
      if(en == 1){
        $('#en').css({"right": makeEnNum+0.3+'%',transition:'0.3s'});
      }
      $('#road').css({"background-position-x": makeNum+4+'%',transition:'0.3s'});
    } else if(k === 37){
      $('#road').css({"background-position-x": makeNum-3+'%',transition:'0.2s'});
    } else if(k === 38){
      i++;
      $('#man').attr('src', 'img/'+i+'.png');
      if(i=== 11){
        i = 0;
      }
    }
  });

  setTimeout(function(){
    $(".img-wrapper").append('<img id="en" src="img/en/snail.png">')
   en = 1;
  },2000);


})